package com.example.ijaz.myfirstapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class register extends AppCompatActivity {

    private DatabaseReference databaseReference,databaseReference1,databaseReference2;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference1 = firebaseDatabase.getReference("Data/Temp");
        databaseReference2 = firebaseDatabase.getReference("Data/Hum");
        mAuth = FirebaseAuth.getInstance();

        EditText FullName = (EditText) findViewById(R.id.fullname);
        EditText email = (EditText) findViewById(R.id.email);
        EditText Password = (EditText) findViewById(R.id.password);
        EditText Location = (EditText) findViewById(R.id.ComAddress);
        EditText Contact = (EditText) findViewById(R.id.PhoneNumber);
        Button SignUp = (Button) findViewById(R.id.Signupbtn);
        TextView LoginNow = (TextView) findViewById(R.id.LoginNowbtn);

        databaseReference1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String Value = snapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        databaseReference2.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String value = snapshot.getValue(String.class);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String Name = FullName.getText().toString().trim();
                String Email = email.getText().toString().trim();
                String password = Password.getText().toString().trim();
                String PhoneNumber = Contact.getText().toString().trim();
                String Address = Location.getText().toString().trim();

                ProgressDialog progressDialog = new ProgressDialog(register.this);
                progressDialog.setTitle("Registering...Please Wait!");
                progressDialog.show();


                if (TextUtils.isEmpty(Email) || TextUtils.isEmpty(password)) {
                    Toast.makeText(getApplicationContext(), "Please enter email and password!!", Toast.LENGTH_LONG).show();
                } else {
                    mAuth.createUserWithEmailAndPassword(Email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                progressDialog.dismiss();
                                User user = new User(Name,Email,PhoneNumber,Address);
                                FirebaseDatabase.getInstance().getReference("Users")
                                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(user);

                                Toast.makeText(getApplicationContext(), "Registration successful!", Toast.LENGTH_LONG).show();

                            } else {
                                progressDialog.dismiss();
                                Toast.makeText(getApplicationContext(), "Registration Failed", Toast.LENGTH_LONG).show();
                                return;
                            }
                        }
                    });

                }
            }
        });


        LoginNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(register.this, login.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
