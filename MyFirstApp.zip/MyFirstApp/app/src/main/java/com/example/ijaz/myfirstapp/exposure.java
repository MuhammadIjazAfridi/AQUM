package com.example.ijaz.myfirstapp;


import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.Random;

import de.nitri.gauge.Gauge;

public class exposure extends Fragment {
    private Gauge gauge1;
    private TextView textView,textViews,textView1,paragraph,paragraphs,paragraph1,paragraph2,paragraph3, paragraph4,paragraph5,paragraph6,paragraph7,paragraph8,paragraph9,paragraph10;
    private Button blink;
    private final Random RAND = new Random();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exposure, container, false);
        gauge1 = (Gauge) view.findViewById(R.id.gauge1);
        mTimer.start();
        blink = (Button) view.findViewById(R.id.blink);
        textView =   view.findViewById(R.id.my_text_view1);
        textView1 =  view.findViewById(R.id.my_text_view3);
        textViews =  view.findViewById(R.id.my_text_view2);
        paragraph =  view.findViewById(R.id.my_paragraph_view1);
        paragraphs = view.findViewById(R.id.my_paragraph_view2);
        paragraph1 = view.findViewById(R.id.my_paragraph_view3);
        paragraph2 = view.findViewById(R.id.my_paragraph_view4);
        paragraph3 = view.findViewById(R.id.my_paragraph_view5);
        paragraph4 = view.findViewById(R.id.my_paragraph_view6);
        paragraph5 = view.findViewById(R.id.my_paragraph_view7);
        paragraph6 = view.findViewById(R.id.my_paragraph_view8);
        paragraph7 = view.findViewById(R.id.my_paragraph_view9);
        paragraph8 = view.findViewById(R.id.my_paragraph_view10);
        paragraph9 = view.findViewById(R.id.my_paragraph_view11);
        paragraph10 =view.findViewById(R.id.my_paragraph_view12);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (paragraph.getVisibility() == View.GONE) {
                    paragraph.setVisibility(View.VISIBLE);

                } else {
                    paragraph.setVisibility(View.GONE);
                }
            }
        });

        textViews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(paragraphs.getVisibility() == View.GONE){
                    paragraphs.setVisibility(View.VISIBLE);

                }else{
                    paragraphs.setVisibility(View.GONE);
                }
            }
        });

        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (paragraph1.getVisibility() == View.GONE) {
                    paragraph1.setVisibility(View.VISIBLE);

                    if (paragraph2.getVisibility() == View.GONE) {
                        paragraph2.setVisibility(View.VISIBLE);

                        if (paragraph3.getVisibility() == View.GONE) {
                            paragraph3.setVisibility(View.VISIBLE);

                            if (paragraph4.getVisibility() == View.GONE) {
                                paragraph4.setVisibility(View.VISIBLE);

                                if (paragraph5.getVisibility() == View.GONE) {
                                    paragraph5.setVisibility(View.VISIBLE);

                                    if (paragraph6.getVisibility() == View.GONE) {
                                        paragraph6.setVisibility(View.VISIBLE);

                                        if (paragraph7.getVisibility() == View.GONE) {
                                            paragraph7.setVisibility(View.VISIBLE);

                                            if (paragraph8.getVisibility() == View.GONE) {
                                                paragraph8.setVisibility(View.VISIBLE);

                                                if (paragraph9.getVisibility() == View.GONE) {
                                                    paragraph9.setVisibility(View.VISIBLE);

                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    paragraph1.setVisibility(View.GONE);
                    paragraph2.setVisibility(View.GONE);
                    paragraph3.setVisibility(View.GONE);
                    paragraph4.setVisibility(View.GONE);
                    paragraph5.setVisibility(View.GONE);
                    paragraph6.setVisibility(View.GONE);
                    paragraph7.setVisibility(View.GONE);
                    paragraph8.setVisibility(View.GONE);
                    paragraph9.setVisibility(View.GONE);


                }
            }
        });

        return view;

    }
    private final CountDownTimer mTimer = new CountDownTimer(10000, 5000) {

        @Override
        public void onTick(final long millisUntilFinished) {
            final int Str = RAND.nextInt((60 - 40) + 1) + 40;
            gauge1.setValue(Str);
            int threshold = 70;

            if (Str >= threshold) {
                blink.setBackgroundColor(getResources().getColor(R.color.red));
                blink.setText("      UnHealthy Environment");

            } else {
                blink.setText("       Healthy Environment");
                blink.setBackgroundColor(getResources().getColor(R.color.green));

            }
        }

        @Override
        public void onFinish() {}
    };

}