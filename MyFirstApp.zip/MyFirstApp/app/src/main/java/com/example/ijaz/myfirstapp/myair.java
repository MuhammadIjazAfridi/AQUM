package com.example.ijaz.myfirstapp;

import static androidx.constraintlayout.motion.utils.Oscillator.TAG;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.Nullable;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import de.nitri.gauge.Gauge;

public class myair extends Fragment {

    private TextView textView1, paragraphs, textView2, paragraphs2;
    private GraphView graphView, bar_Graph;
    private Button blink;
    private Gauge gauge1, gauge2, gauge3, gauge4;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_myair, container, false);

        textView1 = view.findViewById(R.id.my_text_view1);
        paragraphs = view.findViewById(R.id.my_paragraph_view1);
        textView2 = view.findViewById(R.id.my_text_view2);
        paragraphs2 = view.findViewById(R.id.my_paragraph_view2);

        graphView = view.findViewById(R.id.idGraphView);
        bar_Graph = view.findViewById(R.id.bar_graph);
        blink = view.findViewById(R.id.blink);

        gauge1 = (Gauge) view.findViewById(R.id.gauge1);
        gauge2 = (Gauge) view.findViewById(R.id.gauge2);
        gauge3 = (Gauge) view.findViewById(R.id.gauge3);
        gauge4 = (Gauge) view.findViewById(R.id.gauge4);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        String uid = mAuth.getCurrentUser().getUid();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users/" + uid + "/data");
//        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users/Rq37ACVmy2R3YYNUfpTCkKmJKxE2/data");
        databaseReference.limitToLast(1).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String previousChildName) {
                Double coValue = dataSnapshot.child("CO").getValue(Double.class);
                Double co2Value = dataSnapshot.child("CO2").getValue(Double.class);
                Double no2Value = dataSnapshot.child("NO2").getValue(Double.class);
                Double so2Value = dataSnapshot.child("SO2").getValue(Double.class);
                Double humidity = dataSnapshot.child("Humidity").getValue(Double.class);
                Double temp = dataSnapshot.child("Temperature").getValue(Double.class);

                int coFloatValue = coValue.intValue();
                int co2FloatValue = co2Value.intValue();
                int no2FloatValue = no2Value.intValue();
                int so2FloatValue = so2Value.intValue();
                int humidityFloatValue = humidity.intValue();
                int tempFloatValue = temp.intValue();


                gauge1.setValue(tempFloatValue);
                gauge2.setValue(humidityFloatValue);
                gauge3.setValue(coFloatValue);
                gauge4.setValue(co2FloatValue);

                if (coFloatValue >= 200) {
                    blink.setBackgroundColor(getResources().getColor(R.color.red));
                    blink.setText("      Unhealty! Leave the Environment! ");

                } else {
                    blink.setText("       Healthy Environment to Stay!");
                    blink.setBackgroundColor(getResources().getColor(R.color.green));
                }

                graphView.removeAllSeries();

                double[] tempValues = {25.0, 30.2, 34.8, 28.5, 35.1, 26.9, 30.2, 34.8, 28.5, tempFloatValue};
                double[] humidityValues = {60.0, 45.1, 50.5, 42.3, 39.8, 36.2, 45.1, 50.5, 42.3, humidityFloatValue};

                DataPoint[] tempDataPoints = new DataPoint[tempValues.length];
                DataPoint[] humidityDataPoints = new DataPoint[humidityValues.length];

                for (int i = 0; i < tempValues.length; i++) {
                        tempDataPoints[i] = new DataPoint(i, tempValues[i]);
                        humidityDataPoints[i] = new DataPoint(i, humidityValues[i]);
                }

                LineGraphSeries<DataPoint> tempSeries = new LineGraphSeries<>(tempDataPoints);
                LineGraphSeries<DataPoint> humiditySeries = new LineGraphSeries<>(humidityDataPoints);

                graphView.addSeries(tempSeries);
                tempSeries.setColor(Color.RED);
                tempSeries.setThickness(8);

                graphView.addSeries(humiditySeries);
                humiditySeries.setColor(Color.CYAN);
                humiditySeries.setThickness(8);

                graphView.getViewport().setYAxisBoundsManual(true);
                graphView.getViewport().setMinY(0);
                graphView.getViewport().setMaxY(100);

                graphView.getViewport().setXAxisBoundsManual(true);
                graphView.getViewport().setMinX(0);
                graphView.getViewport().setMaxX(10);

                bar_Graph.removeAllSeries();

                BarGraphSeries<DataPoint> no2Series = new BarGraphSeries<>(new DataPoint[]{
                            new DataPoint(2, no2FloatValue * 100),
                });
                no2Series.setDrawValuesOnTop(true);
                no2Series.setColor(Color.BLACK);
                no2Series.setDataWidth(4);
                no2Series.setValuesOnTopColor(Color.BLACK);
                bar_Graph.addSeries(no2Series);


                BarGraphSeries<DataPoint> coSeries = new BarGraphSeries<>(new DataPoint[]{
                        new DataPoint(3, coFloatValue),
                });
                coSeries.setSpacing(10);
                coSeries.setDrawValuesOnTop(true);
                coSeries.setColor(Color.RED);
                coSeries.setDataWidth(4);
                coSeries.setValuesOnTopColor(Color.BLACK);
                bar_Graph.addSeries(coSeries);

                BarGraphSeries<DataPoint> co2Series = new BarGraphSeries<>(new DataPoint[]{
                        new DataPoint(4, co2FloatValue / 100),
                });
                co2Series.setDrawValuesOnTop(true);
                co2Series.setColor(Color.GREEN);
                co2Series.setDataWidth(4);
                co2Series.setValuesOnTopColor(Color.BLACK);
                bar_Graph.addSeries(co2Series);


                BarGraphSeries<DataPoint> so2Series = new BarGraphSeries<>(new DataPoint[]{
                        new DataPoint(5, so2FloatValue),
                });
                so2Series.setDrawValuesOnTop(true);
                so2Series.setColor(Color.BLUE);
                so2Series.setDataWidth(4);
                so2Series.setValuesOnTopColor(Color.BLACK);
                bar_Graph.addSeries(so2Series);

                bar_Graph.getViewport().setYAxisBoundsManual(true);
                bar_Graph.getViewport().setMinY(0);
                bar_Graph.getViewport().setMaxY(300);

                bar_Graph.getViewport().setXAxisBoundsManual(true);
                bar_Graph.getViewport().setMinX(0);
                bar_Graph.getViewport().setMaxX(10);

                LegendRenderer legend = bar_Graph.getLegendRenderer();
                legend.setVisible(true);
                legend.setAlign(LegendRenderer.LegendAlign.TOP);
                legend.setTextSize(20);
                legend.setSpacing(10);

                legend.setFixedPosition(0, 0);
                legend.setMargin(10);
                legend.setWidth(200);

                coSeries.setTitle("CO");
                co2Series.setTitle("CO2");
                no2Series.setTitle("NO2");
                so2Series.setTitle("SO2");

                }
            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @androidx.annotation.Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @androidx.annotation.Nullable String s) {
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "onCancelled", databaseError.toException());
            }
        });

        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(paragraphs.getVisibility() == View.GONE){
                    paragraphs.setVisibility(View.VISIBLE);

                }else{
                    paragraphs.setVisibility(View.GONE);
                }
            }
        });
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(paragraphs2.getVisibility() == View.GONE){
                    paragraphs2.setVisibility(View.VISIBLE);

                }else{
                    paragraphs2.setVisibility(View.GONE);
                }
            }
        });

        return view;
    }

}