package com.example.ijaz.myfirstapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class login extends AppCompatActivity {

    private DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private ProgressDialog mProgress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        EditText Email = (EditText) findViewById(R.id.email);
        EditText Password = (EditText) findViewById(R.id.password);
        TextView RegisterNow = (TextView) findViewById(R.id.Registerbtn);
        TextView forgetPassword = (TextView) findViewById(R.id.forgotpassword);
        Button Login = (Button) findViewById(R.id.login);




        forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(login.this, forgetPassword.class);
                startActivity(intent);
                finish();
            }
        });

        RegisterNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(login.this, register.class);
                startActivity(intent);
                finish();
            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String emailtxt = Email.getText().toString();
                String Passwordtxt = Password.getText().toString();

                ProgressDialog progressDialog = new ProgressDialog(login.this);
                progressDialog.setTitle("processing...Please Wait!");
                progressDialog.show();

                if (TextUtils.isEmpty(emailtxt) || TextUtils.isEmpty(Passwordtxt)) {
                    Toast.makeText(login.this, "Feilds Should Not Be Empty", Toast.LENGTH_SHORT).show();
                } else {
                    progressDialog.dismiss();
                    mAuth.signInWithEmailAndPassword(emailtxt, Passwordtxt).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                progressDialog.dismiss();
                                Intent intent = new Intent(login.this, NavigationDrawer.class);
                                startActivity(intent);
                                finish();
                                                Toast.makeText(login.this, " Successfully Sign In", Toast.LENGTH_SHORT).show();

                                            }
                             else {
                                progressDialog.dismiss();
                                Toast.makeText(login.this, "Make sure you login with \n correct Email and Password", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }
}
