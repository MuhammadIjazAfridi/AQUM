package com.example.ijaz.myfirstapp;

import static androidx.constraintlayout.motion.utils.Oscillator.TAG;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.Nullable;


public class BlankFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_blank, container, false);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        String uid = mAuth.getCurrentUser().getUid();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users/" + uid + "/data");
        databaseReference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String previousChildName) {
//                String key = dataSnapshot.getKey();

                        Double coValue = dataSnapshot.child("CO").getValue(Double.class);
                        Double co2Value = dataSnapshot.child("CO2").getValue(Double.class);
                        Double tempValue = dataSnapshot.child("Temperature").getValue(Double.class);


                        Log.d(TAG, "CO value: " + coValue);
                        Log.d(TAG, "CO2 value: " + co2Value);
                        Log.d(TAG, "Temperature value: " + tempValue);


                        TextView coTextView = (TextView) view.findViewById(R.id.coTextView);
                        TextView co2TextView = (TextView) view.findViewById(R.id.co2TextView);
                        TextView tempTextView = (TextView) view.findViewById(R.id.tempTextView);

                        coTextView.setText(String.valueOf(coValue));
                        co2TextView.setText(String.valueOf(co2Value));
                        tempTextView.setText(String.valueOf(tempValue));
                    }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @androidx.annotation.Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @androidx.annotation.Nullable String previousChildName) {

            }

            @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.w(TAG, "onCancelled", databaseError.toException());
                    }
                });

return view;
    }
}