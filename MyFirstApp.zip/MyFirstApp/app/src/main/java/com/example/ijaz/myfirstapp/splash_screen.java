package com.example.ijaz.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class splash_screen extends AppCompatActivity {

//    AnimationDrawable AniAnimation;
    private ImageView imageView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        imageView = (ImageView) findViewById(R.id.image);
//        imageView.setBackgroundResource(R.drawable.animation);
//        AniAnimation = (AnimationDrawable) imageView.getBackground();
        ;
    }
        @Override
        public void onWindowFocusChanged(boolean hasFocus) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
            super.onWindowFocusChanged(hasFocus);
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
            imageView.startAnimation(animation);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(splash_screen.this, login.class);
                startActivity(intent);
                finish();

            }
        },3000);

    }

}