package com.example.ijaz.myfirstapp;

public class User {
    public String Name, Email,PhoneNumber,Address;

    public User() {
    }

    public User(String Name, String Email,String PhoneNumber,String Address) {
        this.Name = Name;
        this.Email = Email;
        this.PhoneNumber = PhoneNumber;
        this.Address = Address;

    }

}
