package com.example.ijaz.myfirstapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class shop extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.fragment_shop, container, false);

        Button button = (Button) view.findViewById(R.id.learn);
        button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                Intent iView = new Intent(Intent.ACTION_VIEW);
                iView.setData(Uri.parse("https://www.usatoday.com/story/tech/reviewedcom/2020/09/16/home-air-quality-monitors-what-they-and-should-you-buy-one/5804450002/"));
                startActivity(iView);
            }

        });
        return view;
    }
}