package com.example.ijaz.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class edit_Profile extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        final EditText pNumber = (EditText) findViewById(R.id.pNumber);
        final EditText Address = (EditText) findViewById(R.id.AddressId);
        final Button Submit = (Button) findViewById(R.id.submit);

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String Number = pNumber.getText().toString().trim();
                String Addrese = Address.getText().toString().trim();

                if (!TextUtils.isEmpty(Number)) {

                    String id=databaseReference.push().getKey();
                    Edit edit = new Edit(Number, Addrese);
                    FirebaseDatabase.getInstance().getReference("Users")
                            .child(id).setValue(edit);
                    Toast.makeText(getApplicationContext(), "Data added successfully!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Data cannot be added...Failed!", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            });

        }
    }
