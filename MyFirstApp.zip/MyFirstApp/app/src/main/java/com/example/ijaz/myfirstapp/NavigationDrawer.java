package com.example.ijaz.myfirstapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class NavigationDrawer extends AppCompatActivity {

    DrawerLayout drawerLayout;
    NavigationView Navi_bar;
    Toolbar toolbar;
    BottomNavigationView bottom_navigaion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_drawer);

        drawerLayout = findViewById(R.id.drawer_layout);
        Navi_bar = findViewById(R.id.Navi_bar);
        toolbar = findViewById(R.id.toolbar);
        bottom_navigaion = findViewById(R.id.bottom_navigaion);

        setSupportActionBar(toolbar);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.OpenDrawer, R.string.CloseDrawer);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        drawerLayout.closeDrawer(GravityCompat.START);

Navi_bar.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.logout) {

            AlertDialog.Builder logout = new AlertDialog.Builder(NavigationDrawer.this);
            logout.setTitle("LOGOUT");
            logout.setCancelable(true);
            logout.setIcon(R.drawable.ic_baseline_logout_24);
            logout.setMessage("Are you sure you want to logout?");
            logout.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(NavigationDrawer.this, login.class);
                    startActivity(intent);
                    finishAffinity();
                }
            });
            logout.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Toast.makeText(NavigationDrawer.this, "Welcome Back!", Toast.LENGTH_SHORT).show();
                }
            });
            logout.show();
        }
        else if (id == R.id.about) {

            Intent intent = new Intent(NavigationDrawer.this, About.class);
            startActivity(intent);
        }
        else if (id == R.id.setting) {


            Intent intent = new Intent(NavigationDrawer.this, setting.class);
            startActivity(intent);
        }
        else if (id == R.id.profile) {

//            loadFrag(new userProfile(), false);
            Intent intent = new Intent(NavigationDrawer.this, myProfile.class);
            startActivity(intent);
        }
//        else if (id == R.id.help) {
//
//
//
//        }
        return false;
    }
});


        bottom_navigaion.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener(){
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            int id = item.getItemId();

            if (id == R.id.home) {

                loadFrag(new home(), true);

            } else if (id == R.id.myair) {

                loadFrag(new myair(), false);

            } else if (id == R.id.map) {

                Intent intent = new Intent(NavigationDrawer.this, MapsActivity.class);
                startActivity(intent);

            } else if (id == R.id.exposure) {

                loadFrag(new exposure(), false);

            } else if (id == R.id.shop) {

                loadFrag(new shop(), false);
            }
            return true;
        }
        });
        bottom_navigaion.setSelectedItemId(R.id.home);
    }


    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }else {
            super.onBackPressed();
        }
    }

    public void loadFrag(Fragment fragment,boolean flag){
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        if (flag)
            ft.add(R.id.container ,fragment);
        else
            ft.replace(R.id.container ,fragment);
        ft.commit();
    }
}
