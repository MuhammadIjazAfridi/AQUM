package com.example.ijaz.myfirstapp;

public class Edit {

    public String Number, Address;

    public Edit() {
    }

    public Edit(String Number, String Address) {
        this.Number = Number;
        this.Address = Address;
    }

}
