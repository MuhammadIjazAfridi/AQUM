package com.example.ijaz.myfirstapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class setting extends AppCompatActivity implements View.OnClickListener {

    private Button edit;
    private FirebaseUser user;
    private DatabaseReference reference;
    private String userID;
    FirebaseAuth auth;
    ProgressDialog dialog;

    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageReference = storage.getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        TextView logoutt = (TextView) findViewById(R.id.logouut);
        TextView change_password = (TextView) findViewById(R.id.change_password);
        TextView deactivate = (TextView) findViewById(R.id.deactivate_account);
        TextView new_Version = (TextView) findViewById(R.id.version);


        logoutt.setOnClickListener(this);
        change_password.setOnClickListener(this);
        deactivate.setOnClickListener(this);
        new_Version.setOnClickListener(this);

        auth = FirebaseAuth.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userID = user.getUid();

        final TextView fullNameTextView = (TextView) findViewById(R.id.NameTittle);
        final TextView emailTextView = (TextView) findViewById(R.id.EmailTittle);

        reference.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User usersProfile = snapshot.getValue(User.class);
                if (usersProfile != null) {
                    String Name = usersProfile.Name;
                    String Email = usersProfile.Email;

                    fullNameTextView.setText(Name);
                    emailTextView.setText(Email);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(setting.this, "Something Wrong Happened", Toast.LENGTH_SHORT).show();
            }
        });

        edit = findViewById(R.id.upload);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              Intent edit = new Intent(setting.this,myProfile.class);
              startActivity(edit);

            }
        });
        Switch notificationSwitch = findViewById(R.id.notification);

        notificationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    Toast.makeText(setting.this, " Enable Notifications", Toast.LENGTH_SHORT).show();
//                    NotificationManager notificationManager = getSystemService(NotificationManager.class);
//                    NotificationChannel channel = new NotificationChannel("channel id","Channel Name",NotificationManager.IMPORTANCE_DEFAULT);
//                    notificationManager.createNotificationChannel(channel);
//
//                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this,"channel_id").setSmallIcon(R.drawable.ic_baseline_notifications_active_24)
//                            .setContentTitle("Alert Notifications")
//                            .setContentText("Please Leave your room and take some frsh air")
//                            .setPriority(NotificationCompat.PRIORITY_DEFAULT);
//
//                    notificationManager.notify(notificationId,builder.build());
                }
                else{
                    Toast.makeText(setting.this, " Disable Notifications", Toast.LENGTH_SHORT).show();
                    NotificationManager notificationManager = getSystemService(NotificationManager.class);
                    notificationManager.cancelAll();
                }
            }
        });
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.logouut:
                AlertDialog.Builder logout = new AlertDialog.Builder(setting.this);
                logout.setTitle("LOGOUT");
                logout.setCancelable(true);
                logout.setIcon(R.drawable.ic_baseline_logout_24);
                logout.setMessage("Are you sure you want to logout?");
                logout.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(setting.this, login.class);
                        startActivity(intent);
                        finishAffinity();
                    }
                });
                logout.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(setting.this, "Welcome Back!", Toast.LENGTH_SHORT).show();
                    }
                });
                logout.show();
                break;

            case R.id.change_password:
                Intent intent = new Intent(setting.this, update_password.class);
                startActivity(intent);
                break;
            case R.id.version:

                AlertDialog.Builder new_Version = new AlertDialog.Builder(setting.this);
                new_Version.setTitle("   APP-VERSION  ");
                new_Version.setCancelable(true);
                new_Version.setIcon(R.drawable.ic_baseline_info_24);
                new_Version.setMessage("        minSdk 21\n\n" +
                        "        targetSdk 32\n\n" +
                        "        versionCode 1\n\n" +
                        "        versionName 1.0 ");
                new_Version.show();

             break;
            case R.id.deactivate_account:
                AlertDialog.Builder deactivate = new AlertDialog.Builder(setting.this);
                deactivate.setTitle("     DE-ACTIVATE ");
                deactivate.setCancelable(true);
                deactivate.setIcon(R.drawable.ic_baseline_no_accounts_24);
                deactivate.setMessage("Are you sure you want to deactivate your account?");
                deactivate.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        user.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), " Your account has been deactivated!", Toast.LENGTH_LONG).show();
                                    startActivity(new Intent(setting.this, register.class));
                                    finish();
                                } else {
                                    Toast.makeText(getApplicationContext(), " Something Wrong happened! Please try agian later!", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                                }
                            });
                deactivate.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Toast.makeText(setting.this, "Welcome Back!", Toast.LENGTH_SHORT).show();
                                }
                            });
                deactivate.show();
                break;

        }

        }

    }

